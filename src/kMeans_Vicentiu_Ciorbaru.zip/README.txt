DataSet sources:

https://archive.ics.uci.edu/ml/machine-learning-databases/hepatitis/
https://archive.ics.uci.edu/ml/machine-learning-databases/iris/
https://archive.ics.uci.edu/ml/machine-learning-databases/glass/
